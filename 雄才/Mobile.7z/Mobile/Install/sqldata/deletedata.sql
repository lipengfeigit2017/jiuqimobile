--
-- 删除数据表 `qs_navigation_mobile`
--

DROP TABLE IF EXISTS `qs_navigation_mobile`;

--
-- 删除数据表 `qs_ad_mobile`
--

DROP TABLE IF EXISTS `qs_ad_mobile`;
